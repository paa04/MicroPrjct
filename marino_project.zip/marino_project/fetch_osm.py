"""Fallback public OSM map-API snapshot, used when Overpass is unavailable.

Downloads a bounded area in cached tiles, retains OSM element identities and
constructs a pedestrian graph. OSM data copyright OpenStreetMap contributors,
ODbL: https://www.openstreetmap.org/copyright .
"""
from pathlib import Path
import json, time, urllib.request, xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
import geopandas as gpd
import numpy as np
import osmnx as ox
from shapely.geometry import box

ROOT=Path(__file__).resolve().parent
CACHE=ROOT/'cache'

def fetch(tile):
    name,bounds=tile
    path=CACHE/'tiles'/f'{name}.osm'
    if path.exists(): return path
    url='https://api.openstreetmap.org/api/0.6/map?bbox='+','.join(f'{v:.7f}' for v in bounds)
    for attempt in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'MarinoNESAcademicProject/2.0 (noncommercial spatial analysis)'})
            with urllib.request.urlopen(req,timeout=45) as r: data=r.read()
            ET.fromstring(data)
            path.write_bytes(data)
            print(name,len(data),flush=True)
            time.sleep(.5)
            return path
        except Exception:
            if attempt==2: raise
            time.sleep(2+attempt*3)

def main(buffer=3000):
    CACHE.mkdir(exist_ok=True); (CACHE/'tiles').mkdir(exist_ok=True)
    b=gpd.read_file(CACHE/'boundary.geojson').to_crs(32637)
    boundary=b.geometry.iloc[0]
    polygon=gpd.GeoSeries([boundary.buffer(buffer)],crs=32637).to_crs(4326).iloc[0]
    x0,y0,x1,y1=polygon.bounds
    tiles=[]
    for ix,x in enumerate(np.arange(x0,x1,.02)):
        for iy,y in enumerate(np.arange(y0,y1,.02)):
            bounds=(x,y,min(x+.02,x1),min(y+.02,y1))
            if box(*bounds).intersects(polygon): tiles.append((f'{buffer}_{ix}_{iy}',bounds))
    print('Tiles:',len(tiles),flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool: paths=list(pool.map(fetch,tiles))
    elements={}
    for path in paths:
        for e in ET.parse(path).getroot():
            if e.tag in ('node','way','relation'):
                key=(e.tag,e.attrib['id'])
                if key not in elements or int(e.get('version','0'))>int(elements[key].get('version','0')): elements[key]=e
    root=ET.Element('osm',version='0.6',generator='MarinoNESAcademicProject/2.0')
    for key in sorted(elements,key=lambda k:({'node':0,'way':1,'relation':2}[k[0]],int(k[1]))):root.append(elements[key])
    full=CACHE/'snapshot.osm'; ET.ElementTree(root).write(full,encoding='utf-8',xml_declaration=True)
    raw=ox.features_from_xml(full,tags={'building':True}).to_crs(32637)
    raw=raw[raw.geometry.geom_type.isin(['Polygon','MultiPolygon'])].copy()
    if 'addr:street' in raw and 'addr:housenumber' in raw:
        addr=raw[raw['addr:street'].notna() & raw['addr:housenumber'].notna()].copy()
        addr['address']=addr['addr:street'].astype(str)+', '+addr['addr:housenumber'].astype(str)
        addr=addr[['address','geometry']].reset_index().rename(columns={'id':'osm_id'})
        addr.to_crs(4326).to_file(CACHE/'address_buildings.geojson',driver='GeoJSON')
    raw=raw[raw.geometry.representative_point().within(boundary)]
    total_buildings=len(raw)
    raw=raw[raw['building'].isin(['apartments','residential','house','detached','semidetached_house','terrace','dormitory'])].copy()
    cols=['building','geometry']+[c for c in ['building:levels','addr:street','addr:housenumber'] if c in raw]
    buildings=raw[cols].reset_index().rename(columns={'id':'osm_id'})
    buildings.to_crs(4326).to_file(CACHE/'buildings.geojson',driver='GeoJSON')
    walk=ET.Element('osm',version='0.6',generator='MarinoNESAcademicProject/2.0')
    ways=[]; needed=set()
    # Corresponds to OSMnx pedestrian filtering; allow explicit pedestrian access.
    excluded={'motorway','motorway_link','trunk','trunk_link','raceway','construction','proposed','abandoned','bus_guideway'}
    for (kind,_),e in elements.items():
        if kind!='way':continue
        tags={t.attrib['k']:t.attrib['v'] for t in e.findall('tag')}
        h=tags.get('highway')
        if not h or h in excluded or tags.get('area')=='yes' or tags.get('foot') in ('no','private'):continue
        if tags.get('access') in ('no','private') and tags.get('foot') not in ('yes','designated','permissive'):continue
        ways.append(e); needed.update(n.attrib['ref'] for n in e.findall('nd'))
    for nid in sorted(needed,key=int):
        if ('node',nid) in elements:walk.append(elements['node',nid])
    for way in ways:walk.append(way)
    fp=CACHE/'walk_snapshot.osm'; ET.ElementTree(walk).write(fp,encoding='utf-8',xml_declaration=True)
    G=ox.graph_from_xml(fp,bidirectional=True,simplify=False,retain_all=False)
    G=ox.project_graph(G,to_crs=32637)
    ox.save_graphml(G,CACHE/f'walk_{float(buffer)}.graphml')
    manifest={'retrieved_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':'https://api.openstreetmap.org/api/0.6/map',
        'license':'ODbL 1.0; © OpenStreetMap contributors','tile_count':len(paths),'buffer_m':buffer,
        'boundary_osm_relation':455222,'all_building_polygons':total_buildings,'residential_buildings':len(buildings),
        'graph_nodes':len(G),'graph_edges':G.number_of_edges(),'simplified':False,
        'note':'Map API snapshot; no foot=no/private or motorway/trunk. Largest connected component; straight access links to unsimplified graph nodes.'}
    (CACHE/'data_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
