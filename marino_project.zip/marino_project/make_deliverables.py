"""Create the Russian report, reproducible figures, standalone map and defence notes."""
from pathlib import Path
import json,html,math
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4

ROOT=Path(__file__).resolve().parent;R=ROOT/'results';OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
S=json.loads((R/'summary.json').read_text());B=S['best'];P=S['population']
Z=pd.read_csv(R/'priority_zones.csv');C=pd.read_csv(R/'candidates.csv');CL=pd.read_csv(R/'club_demand.csv')
N=pd.read_csv(R/'network_shares.csv');V=pd.read_csv(R/'loo_summary.csv');T=pd.read_csv(R/'sensitivity.csv')
A=json.loads((R/'accessibility.json').read_text());RC=json.loads((R/'robust_choice.json').read_text())
GC=json.loads((R/'grid_convergence.json').read_text())
boundary=gpd.read_file(ROOT/'cache/boundary.geojson').to_crs(32637).geometry.iloc[0]
clubs=gpd.read_file(R/'clubs.geojson').to_crs(32637);demand=gpd.read_file(R/'demand.geojson').to_crs(32637)
f=lambda x,n=0:f'{x:,.{n}f}'.replace(',',' ')
BLUE='#174F59';ORANGE='#BD5B32';GRAY='#53656C'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
method_names={'random_expected':'Случайный выбор','population_500m':'Население в 500 м','farthest_club':'Дальше от конкурентов','uniform_euclidean_network':'Равномерная плотность + прямая','population_euclidean_network':'Население домов + прямая','population_walk_single_club':'Пешком: спрос нового клуба','population_walk_network':'Пешком: прирост сети'}
spec_names={'base_walk':'Базовая пешеходная','straight_line':'Расстояние по прямой','footprint_only':'Площадь домов без этажности','walk_15min':'Не более 15 минут пешком','walk_20min':'Не более 20 минут пешком','walk_30min':'Не более 30 минут пешком','exclude_terfit':'Без двух клубов Территории','exclude_pool_clubs':'Без клубов с бассейном','exclude_compact':'Без компактных клубов','add_border':'Два приграничных клуба','add_sportlife':'Добавлен Спорт & Лайф','add_uncertain':'Две неподтверждённые записи','add_all_four':'Все четыре дополнительные записи'}

def map_base():
    fig,ax=plt.subplots(figsize=(10,6.2),layout='constrained')
    gpd.GeoSeries([boundary],crs=32637).plot(ax=ax,color='#F2F4F0',edgecolor=GRAY,linewidth=1)
    ax.set_aspect('equal');ax.axis('off')
    # Kilometre coordinates are only an internal projection; add a distance scale.
    x0,y0,x1,y1=boundary.bounds;ax.plot([x0+250,x0+1250],[y0+180,y0+180],c=GRAY,lw=2)
    ax.text(x0+750,y0+210,'1 км',ha='center',fontsize=9)
    fig.text(.98,.01,'© OpenStreetMap contributors · ODbL',ha='right',fontsize=8,color=GRAY)
    return fig,ax

def figures():
    fig,ax=map_base();ax.scatter(demand.geometry.x,demand.geometry.y,s=8+35*demand.residents/demand.residents.max(),c='#CAD7C7',alpha=.8)
    for _,r in clubs.iterrows():
        ax.scatter(r.geometry.x,r.geometry.y,s=42,c=ORANGE if r.network=='DDX' else BLUE,zorder=3)
        ax.annotate(str(r.id),(r.geometry.x,r.geometry.y),xytext=(5,5),textcoords='offset points',fontsize=9)
    ax.set_title('Реестр клубов и жилые здания Марьино',loc='left',weight='bold',color=BLUE)
    fig.savefig(R/'07_registry.png',dpi=180);plt.close(fig)
    fig,ax=map_base();e=C[C.eligible]
    sc=ax.scatter(e.x,e.y,c=e.gain_walk/1000,s=10,marker='s',cmap='viridis',vmin=0)
    for _,r in clubs.iterrows():ax.scatter(r.geometry.x,r.geometry.y,s=24,c=ORANGE if r.network=='DDX' else '#252F33',edgecolors='white',linewidth=.6,zorder=4)
    for _,r in Z.iterrows():
        ax.scatter(r.x,r.y,s=180,marker='*',c='#E86838',edgecolors='white',linewidth=.8,zorder=5)
        ax.annotate('Зона '+str(int(r.zone_rank)),(r.x,r.y),xytext=(12,-17 if r.zone_rank==1 else 10),textcoords='offset points',fontsize=10,weight='bold',color='#8D361F')
    fig.colorbar(sc,ax=ax,shrink=.8,label='Прирост сети, тыс. эквивалентов жителей')
    ax.set_title('Три зоны для поиска помещения DDX',loc='left',weight='bold',color=BLUE)
    fig.savefig(R/'08_priority_zones.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained');v=V.sort_values('mean_error_m',ascending=False)
    ax.barh([method_names[x] for x in v.method],v.mean_error_m,color=[ORANGE if x=='population_walk_network' else BLUE for x in v.method])
    for i,value in enumerate(v.mean_error_m):ax.text(value+25,i,f(value)+' м',va='center',fontsize=10)
    ax.set_xlim(0,4100);ax.set_xlabel('Среднее расстояние до фактического адреса');ax.set_title('Leave-one-out: 9 клубов внутри Марьино',loc='left',color=BLUE,weight='bold')
    fig.savefig(R/'09_validation_ru.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained');ns=N.sort_values('share_walk')
    ax.barh(ns.network,100*ns.share_walk,color=[ORANGE if x=='DDX' else BLUE for x in ns.network])
    ax.set_xlabel('Доля модельного спроса жителей, %');ax.set_title('Распределение спроса до открытия',loc='left',color=BLUE,weight='bold')
    for i,value in enumerate(100*ns.share_walk):ax.text(value+.3,i,f(value,1)+'%',va='center',fontsize=9)
    ax.set_xlim(0,25);fig.savefig(R/'10_shares_ru.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8.6,4.5),layout='constrained')
    theta=np.array([.03,.05,.08]);margins=np.array([800,1000,1500]);vals=B['gain_walk']*margins[:,None]*theta[None,:]/1e6
    im=ax.imshow(vals,cmap='YlGnBu');ax.set_xticks(range(3),['3%','5%','8%']);ax.set_yticks(range(3),['800 ₽','1 000 ₽','1 500 ₽'])
    ax.set_xlabel('Сценарная доля потенциальных клиентов');ax.set_ylabel('Маржа на клиента в месяц')
    for i in range(3):
        for j in range(3):ax.text(j,i,f(vals[i,j],2),ha='center',va='center',fontsize=17,color='white' if vals[i,j]>3 else BLUE)
    ax.set_title('Предельные ежемесячные расходы, млн ₽',loc='left',weight='bold',color=BLUE)
    fig.savefig(R/'11_break_even_ru.png',dpi=180);plt.close(fig)

sources=[
('Постановка проекта','Проект.pdf; исходный файл пользователя, 4 страницы. Сдача: 6 декабря 23:59 МСК; защита: 9 декабря, 15:30–19:30 МСК.'),
('Исходная теория','Hotelling_R2_Voronoi_Network.pdf, 26.11.2026; исходный файл пользователя, 3 страницы.'),
('OpenStreetMap','https://www.openstreetmap.org/copyright ; граница relation/455222; выгрузка через https://api.openstreetmap.org/api/0.6/map . Дата загрузки 27.11.2026. Идентификаторы POI и домов сохранены.'),
('OSMnx','https://osmnx.readthedocs.io/en/stable/user-reference.html ; версия расчёта 2.2.0.'),
('Население','https://t-j.ru/demography-moscow/ ; вторичная публикация со ссылкой на Росстат: 273 463 на 01.01.2025. Первичная таблица Мосстата не извлечена. Это фиксированный масштаб, а не измеренный спрос.'),
('Муниципалитет','https://asdmom.ru/okrug/ofitsialnaya-statistika/ ; география района, две станции метро. На странице другая, не датированная численность 271 915; эти два значения не смешиваются.'),
('DDX','https://www.ddxfitness.ru/clubs/ddx-marino-ekran/ ; https://www.ddxfitness.ru/clubs/ddx-bratislavskaya/ ; https://www.ddxfitness.ru/clubs/ddx-brateevo-bravo/ . Адреса подтверждены; тарифные страницы в выдаче содержат истёкшие сроки действия.'),
('Spirit','https://spiritfit.ru/clubs/metro-marino/ ; адрес, подписка «Мой клуб» 2 600 ₽/мес.; предложение до 30.11.2026. «От 1 700» относится к ограниченному тарифу.'),
('Z Fitness','https://zfitness.moscow/home ; Перерва, 43 к1. Запись Zebra по этому адресу не считается вторым клубом.'),
('Kometa','https://trainers.kometa.fit/ ; Поречная, 10. Тариф не извлечён.'),
('Magneto','https://magnetofitness.ru/clubs/marino/ ; Марьинский бульвар, 8 к2; бассейн, семейный формат; рекламное предложение от 3 742 ₽/мес.'),
('СССР','https://fitness-cccp.ru/clubs/maryino/ ; Люблинская, 100 к2; круглосуточный клуб с бассейном.'),
('Академия спорта','https://akadem-sport.ru/ ; Новочеркасский бульвар, 10 к1; площадь тренажёрного зала 245 м².'),
('Территория фитнеса','https://terfit.ru/clubs/bratislavskaya/ ; https://terfit.ru/clubs/lyublino/ ; официальные адреса 4 к1 и 29А, семейный формат.'),
('La Salute','https://pro.lasalute.ru/ ; официальный учебный центр на базе клуба, Белореченская, 4; клуб с бассейном.'),
('XFIT','https://www.xfit.ru/club/moskva/xfit-point-lyblinskiy-park/ ; адрес 80 к4, компактная студия. На странице сохранился текст предпродажи: статус учитывается как ограничение.'),
('Закрытие XFIT Марьино','https://www.xfit.ru/news/uvazhaemye-chleny-kluba-xfit-marino/ ; сообщение от 01.06.2026 о прекращении работы 01.03.2026. Клуб на Братиславской, 30 исключён.'),
('Дополнительные конкуренты','https://msk.metrofitness.ru/ ; https://www.fit-l.com/ ; OSM node/6545743487 (Спорт & Лайф); https://moskva.nashigoroda.ru/c/44/n/yvao/marino/ (Winner). Последние две записи не подтверждены как действующие и используются только в стресс-тесте.')]

pages=[]
def page(title,blocks):pages.append((title,blocks))
def p(text):return ('p',text)
def table(headers,rows,widths=None):return ('table',(headers,rows,widths))
def img(name,h=250):return ('img',(str(R/name),h))

def content():
    page('Пространственная стратегия DDX в Марьино',[
        p('<b>Исследовательский проект по микроэкономике · 27 ноября 2026</b>'),
        p('Вопрос исследования: где дополнительный клуб увеличивает суммарный спрос сети, учитывая существующих конкурентов и переток клиентов между собственными клубами? Целевая сеть — DDX, выбранная в исходном прототипе.'),
        p(f'<b>Результат.</b> Для первичного поиска помещения приоритетна зона Братиславской улицы около дома 27 к2: {B["lat"]:.6f}, {B["lon"]:.6f}. Это координаты расчётной точки рядом с адресным ориентиром, а не предложение арендовать этот дом. На сетке 50 м она даёт {f(B["gain_walk"])} эквивалентов жителей дополнительного спроса сети и сохраняет не менее {f(RC["worst_retention_pct"],1)}% максимума в выбранном наборе сценариев.'),
        p('В этой работе рассчитан географический потенциал. Число реальных покупателей, арендная ставка, вместимость и затраты на запуск не наблюдаются. Поэтому рекомендация — искать и сравнивать помещения в обозначенной зоне; безусловная рекомендация открыть клуб или обещание прибыли из данных не следуют.'),
        table(['Состояние исходного проекта','Что выполнено'],[
            ['Теория и прототип кода','Сохранена сетевая целевая функция; уточнена экономическая интерпретация'],
            ['Пустые координаты клубов','13 координат из адресных объектов/POI OSM, таблица аудита'],
            ['Нет реальных геоданных','365 жилых зданий, 98 748 узлов пешеходного графа'],
            ['Нет расчётов и проверки','Сетки 100 и 50 м, 7 методов LOO, 13 спецификаций чувствительности'],
            ['Нет письменной части','Анализ рынка, результаты, рекомендации, ограничения и источники']],[220,285]),
        p('<b>Ключевой отрицательный результат:</b> пешеходная сетевая модель не превзошла евклидову по расстоянию до наблюдаемых адресов. Это ограничивает силу предсказательных утверждений, но не отменяет полезность модели как прозрачного инструмента сравнения локаций.')])
    page('1. Рынок, территория и данные',[
        p('Исследуется доступность полноформатного фитнеса и тренажёрных залов для жителей района Марьино. Административная граница фиксирует происхождение спроса; она не является барьером для посещения клуба. В реестр включены четыре клуба вне района. Марьино удобно для пространственного анализа: плотная жилая застройка, две станции метро, крупные улицы и река создают различия между расстоянием по прямой и фактическим доступом [3, 6].'),
        img('07_registry.png',290),
        p('Номера на карте соответствуют реестру в приложении. Оранжевым обозначены клубы DDX; остальные — тёмным цветом. Светлые точки показывают жилые здания, а не наблюдаемых клиентов.'),
        p('Базовый реестр: 13 клубов, 10 брендов, 9 адресов внутри района. Проверены официальные адреса и закрытие XFIT Марьино. Женские специализированные студии не включены; старое название Zebra не дублирует Z Fitness. Реестр остаётся выборкой релевантных конкурентов, а не доказанно полным перечнем рынка. Дополнительные четыре записи проверяются отдельно [7–18].')])
    page('2. Структура рынка и поведение фирм',[
        p('Рабочая характеристика — дифференцированная конкуренция с локальными зонами обслуживания. Размещение, цена, бассейн, часы работы, групповые программы и доступ в другие клубы сети образуют разные измерения продукта. Поэтому равенство цены и качества далее является упрощающей моделью географической конкуренции, а не установленным свойством рынка.'),
        table(['Игрок / формат','Наблюдаемая информация','Вывод для сопоставления'],[
            ['DDX','Подписка, зал, дополнительные опции по тарифу; Light 1 900 ₽ в индексированной странице с истёкшим сроком','Исторический ценовой ориентир; не текущая котировка'],
            ['Spirit Марьино','«Мой клуб» 2 600 ₽/мес.; «Старт» 1 700 ₽ — 5 посещений','Дешёвый заголовок не равен безлимитному тарифу'],
            ['Magneto','Бассейн 25 м; реклама от 3 742 ₽/мес.','Семейный продукт; условия оплаты необходимо сопоставлять'],
            ['СССР / Территория / La Salute','Бассейн и расширенные услуги; сопоставимая цена не извлечена','Проверяется сценарий исключения бассейнов'],
            ['XFIT Point / Академия спорта','Компактная студия / тренажёрный зал 245 м²','Равенство вместимости с крупными залами неправдоподобно']],[100,240,165]),
        p('Наблюдаемые различия поддерживают роль сервисной и ассортиментной конкуренции. Подписка уменьшает первоначальный платёж, тогда как доступ во всю сеть создаёт ценность, не отражаемую выбором одного ближайшего клуба. Близость к метро и ТЦ может отражать поток посетителей и доступность площадей; модель с домашними адресами этот механизм полностью не охватывает.'),
        p('Барьеры входа в экономической интерпретации: поиск крупного помещения, оборудование, вентиляция и ремонт, необратимые расходы, привлечение персонала и клиентов. Их размер в этой работе не измерен. По одному числу точек нельзя заключить, что какая-либо сеть доминирует по выручке или числу членов.')])
    page('3. Формальная модель пространственного выбора',[
        p('Пусть i — жилое здание, nᵢ — его условное население, θ — доля потенциальных клиентов, lⱼ — координаты клуба, A(j) — его сеть. Существующие адреса фиксированы. Полезность в базовой спецификации:'),
        ('eq','Uᵢⱼ = r − p̄ − τ dG(xᵢ, lⱼ),   τ > 0.'),
        p('dG — длина кратчайшего пешеходного пути с приближённым доступом к графу. В альтернативной спецификации используется евклидово расстояние. При общих r, p̄, τ и полном покрытии каждый потенциальный клиент выбирает ближайший клуб. Если несколько клубов равноудалены, спрос делится поровну между ними.'),
        ('eq','Qⱼ = θ Σᵢ nᵢ sᵢⱼ;     QА = Σⱼ∈А Qⱼ;     ΣА QА = θ Σᵢ nᵢ.'),
        p('Сеть является единым игроком. После добавления клуба в z спрос на все её точки пересчитывается. При общей марже m и ежемесячных расходах новой точки F(z):'),
        ('eq','ΔΠА(z) = m [QА⁺(z) − QА] − F(z).'),
        ('eq','z* ∈ arg max(z∈Lh) ΔΠА(z);    открытие только если max ΔΠА > 0.'),
        p('При постоянных по локациям m и F максимум прибыли совпадает с максимумом прироста сетевого спроса. Поэтому изменение θ, m или общего F меняет финансовый вывод, но не ранжирование точек. В численных таблицах сначала используются эквиваленты жителей до умножения на θ.'),
        p('<b>Каннибализация.</b> Если до открытия вероятность выбора сети равна sᵢА, а вероятность выбора нового клуба после открытия равна aᵢ(z), то прирост сети в эквивалентах жителей составляет Σᵢ nᵢ aᵢ(z)(1−sᵢА). Спрос нового клуба равен Σᵢ nᵢ aᵢ(z). Разность — переток из собственных клубов.'),
        p('<b>Граница теоретического вывода.</b> Это оптимальный ответ сети на фиксированную конфигурацию, а не найденное равновесие Нэша всех сетей. Не решаются одновременный вход, изменение цен и ответ конкурентов. Максимум гарантирован на конечной сетке, но его совпадение с непрерывным максимумом не доказано [2].')])
    page('4. От геоданных к спросу и маршрутам',[
        table(['Компонент','Реализация и ограничения'],[
            ['Плотность спроса','nᵢ = P × (площадь основания × этажность)ᵢ / сумму этих весов. P = 273 463. Это распределение по жилищному фонду, не перепись домов.'],
            ['Жилые здания','365 полигонов из 1 426 зданий внутри границы. Включены жилые типы; building=yes без подтверждения жилого использования исключён. Доля 365/1426 не является оценкой полноты жилого фонда.'],
            ['Этажность','У всех 365 выбранных объектов есть допустимый числовой тег. Это полнота тегов в выборке, а не независимая проверка их точности.'],
            ['Пешеходная сеть','42 кешируемых фрагмента OSM API; буфер 3 км; 98 748 узлов, 234 546 направленных рёбер. Граф двунаправленный, без топологического упрощения.'],
            ['Привязка','Ближайший узел + прямой отрезок доступа. Максимум для дома 75,2 м. Переход через забор на таком отрезке не исключён; входы в ТЦ не обследованы.'],
            ['Кандидаты','Сетка 50 м: 4 555 точек после фильтра доступа; 4 525 после удаления точек ближе 50 м к клубам. Это пространственный скрининг, не список свободных помещений.'],
            ['Время','80 м/мин (4,8 км/ч), одинаковая скорость для всех. Светофоры, транспорт и время внутри зданий не моделируются.']],[110,395]),
        p('Маршруты построены по крупнейшей связной компоненте; пути с запретом прохода исключены согласно использованным тегам. Для параллельных рёбер берётся минимальная длина. Исходные данные кешированы и расчёт повторяется без обращения к сети.'),
        p('Альтернативы спроса и транспорта отделены от базового расчёта: равномерная плотность по площади, веса зданий без этажности, расстояние по прямой, предел 15/20/30 минут. Численность населения влияет пропорционально на объём, но при общей θ и постоянных расходах не меняет оптимальную точку [3–6].')])
    page('5. Куда направить поиск помещения',[
        img('08_priority_zones.png',300),
        table(['Зона / адресный ориентир','Координаты','Прирост, экв. жителей'],[[str(int(r.zone_rank))+'. '+r.nearest_address,f'{r.lat:.6f}; {r.lon:.6f}',f(r.gain_walk)] for _,r in Z.iterrows()],[235,145,125]),
        p('Зоны отобраны последовательно с расстоянием между опорными точками не менее 500 м. Это три альтернативы для одного открытия: их эффекты нельзя суммировать как прогноз трёх новых клубов. Адреса указаны для ориентирования; наличие помещений и разрешённый вид использования не установлены.'),
        p(f'В базовом оптимуме дополнительный спрос сети равен спросу нового клуба: каннибализация составляет 0%. Это следствие конкретного распределения ближайших клубов при равных ценах и качестве. В других точках карты переток между собственными клубами возможен. Доля DDX в модельном спросе возрастает с {f(100*S["base_resident_equivalents"]/P,1)}% до {f(100*(S["base_resident_equivalents"]+B["gain_walk"])/P,1)}%; это не оценка реальных рыночных долей.')])
    page('6. Экономическая интерпретация результата',[
        p(f'В опорной точке ΔD = {f(B["gain_walk"])} эквивалентов жителей. Для θ = 5% это {f(.05*B["gain_walk"])} условных дополнительных клиентов. При марже 1 000 ₽/месяц и расходах 500 000 ₽/месяц сценарный прирост составляет {f(B["profit_month"]/1e6,2)} млн ₽/месяц. Все три экономических параметра заданы условно, а не оценены по данным клуба.'),
        img('11_break_even_ru.png',235),
        p('Значения на рисунке — максимально допустимые ежемесячные расходы F = θmΔD при нулевом приросте прибыли. В F должны войти аренда, персонал и прочие постоянные расходы, а также эквивалент капитальных затрат и требуемой доходности. Это не только арендная плата.'),
        table(['Сценарий','θ / m / F в месяц','ΔΠ, млн ₽/месяц'],[
            ['Осторожный','3%; 800 ₽; 1 500 000 ₽',f((.03*800*B['gain_walk']-1500000)/1e6,2)],
            ['Базовый условный','5%; 1 000 ₽; 500 000 ₽',f(B['profit_month']/1e6,2)],
            ['Расходы выше','5%; 1 000 ₽; 1 500 000 ₽',f((.05*1000*B['gain_walk']-1500000)/1e6,2)]],[140,235,130]),
        p('При полном покрытии рынка выигрыш DDX идёт из перераспределения клиентов конкурентов: около 17,6 тыс. эквивалентов жителей от Территории фитнеса, 16,6 тыс. от Magneto, 8,6 тыс. от Kometa. Это модельный механизм, не наблюдаемый переход клиентов. Разница в бассейнах и услугах может существенно уменьшить фактическое переключение.')])
    page('7. Проверка модели по текущим локациям',[
        p('Каждый из 9 клубов внутри района последовательно удаляется. Все остальные остаются, а сеть удалённого клуба выбирает новую точку на той же сетке с добавлением фактического адреса. Сравниваются семь правил; случайный выбор оценивается точным средним по допустимым точкам. В данные не подгонялись параметры по координатам удалённого клуба.'),
        img('09_validation_ru.png',250),
        p('Средняя ошибка сетевой пешеходной модели — 929 м против 1 792 м у случайного выбора и 824 м у модели «население домов + расстояние по прямой». Следовательно, учёт неоднородного спроса полезен в этом сравнении, а дополнительное преимущество пешеходной метрики по этой метрике не подтверждено. На девяти адресах это описательное сравнение, не оценка точности будущих открытий.'),
        p('Средний процентиль реальных локаций по сетевой пешеходной модели — 76,5. При этом DDX «Люблю Молл» находится лишь около 10,8-го процентиля; ошибка его восстановления — 1,61 км. Модель пропускает важные факторы, например поток ТЦ, сетевой доступ, цены, качество, площади и исторические условия входа.'),
        p('Потеря относительно оптимума сетевой модели по определению равна нулю у самой этой модели, поэтому она не служит независимым доказательством её превосходства. Современная карта конкурентов не совпадает с картой на момент открытия клуба. Это leave-one-out проверка согласованности текущей конфигурации, не out-of-time валидация и не причинный вывод.')])
    page('8. Чувствительность и устойчивость зоны',[
        table(['Спецификация','Сдвиг лучшей точки, м','Результат базовой зоны / максимум'],[[spec_names[r.specification],f(r.shift_m),f(r.baseline_retention_pct,1)+'%'] for _,r in T.iterrows()],[265,110,130]),
        p(f'Переход от сетки 100 м к 50 м увеличивает максимум на {f(GC["gain_improvement_pct"],1)}% и перемещает точку на {f(GC["shift_m"])} м. Это аргумент за рекомендацию зоны, а не точного адреса; численная сходимость непрерывного решения не установлена.'),
        p('Добавление двух приграничных клубов не меняет оптимум. Допущение о работе OSM-записи «Спорт & Лайф» переключает лидера на запад района, но исходная зона сохраняет 95,2% результата. Статус этой записи не подтверждён: она используется как стресс-тест, а не как установленный факт.'),
        p('Для общего множества допустимых точек также максимизирован минимальный относительный результат по 13 спецификациям. Победила та же точка: её худшее отношение к максимуму — 90,8%. Это устойчивость внутри выбранных сценариев, а не статистический доверительный интервал. Удаление конкурентов с бассейном или компактных клубов меняет сам продуктовый рынок; эти сценарии проверяют границы определения рынка.')])
    page('9. Рекомендация и её экономическое основание',[
        p('<b>Первый приоритет:</b> поиск коммерческого помещения в окрестности Братиславской улицы, 27 к2, с первоначальным радиусом обследования около 300 м. Радиус — практический ориентир для поиска, а не доказанная зона одинаковой прибыли. Для каждого найденного входа необходимо заново рассчитать пути и прибыль с индивидуальными расходами.'),
        p('<b>Второй приоритет:</b> Перервинский бульвар около дома 6. В базовой модели он обеспечивает 93,6% прироста лидера; его следует сравнить с первой зоной по аренде, размеру помещения и возможности разместить оборудование.'),
        p('<b>Резерв:</b> западная часть Новочеркасского бульвара около дома 2. Базовый результат составляет 87,5% лидера, однако он зависит от включения компактной «Академии спорта». При её исключении западный спрос уже попадает к DDX и сетевой прирост этой точки обнуляется. Поэтому этот вариант слабее по устойчивости.'),
        table(['Решение','Как использовать расчёт'],[
            ['Ранжировать реальные помещения','Для каждого z считать θmΔD(z) − F(z), а не сравнивать только население рядом'],
            ['Проверить рынок','Уточнить действующий статус малых залов и студий, не смешивать закрытые бренды и новые названия'],
            ['Уточнить продукт','Сопоставить одинаковые тарифы и услуги; проверить, готовы ли клиенты бассейнов переключаться на DDX'],
            ['Проверить ёмкость','Сопоставить сценарный поток с площадью и пиковой загрузкой; оценить возможность обслужить клиентов'],
            ['Принять решение об открытии','Только после оценки θ, маржи, помещения и полного F, включая вложения; сравнить результат с нулём']],[145,360]),
        p('Закрывать или переносить существующие клубы по этому исследованию не рекомендуется. В модели нет наблюдаемых расходов, действующих контрактов, спроса с других территорий и стоимости закрытия. Рекомендация касается одного дополнительного клуба при сохранении существующей сети.')])
    page('10. Что объясняет модель и чего она не доказывает',[
        img('10_shares_ru.png',230),
        p(f'Модельный HHI равен {f(S["hhi_walk"])} пунктам при суммировании долей по сетям. Это индекс распределения условного спроса жителей, не индекс по фактической выручке или членству. Юридические или отраслевые выводы о концентрации на его основе не делаются.'),
        p('Показательный недостаток: компактная «Академия спорта» получает 16,4% модельного спроса, хотя на её сайте указано 245 м² тренажёрного зала. Без вместимости и качества модель может завышать роль маленькой точки. Это диагностический признак ограничений спецификации, а не свидетельство реального лидерства клуба.'),
        p('После открытия средняя модельная ходьба до ближайшего клуба сокращается с 8,38 до 7,92 минуты. Доля жителей в пределах 15 минут меняется лишь с 97,59% до 97,67%. Значит, основная логика результата — перехват существующего географического спроса, а не устранение крупной зоны без фитнеса.'),
        p('Не наблюдаются реальные клиенты по адресам, доходы и возрастной состав домов, дневные потоки, лояльность бренду, вместимость, аренда, капитальные расходы и реакция конкурентов. OSM может содержать пропуски и устаревшие объекты. Поэтому числа спроса и прибыли условны; пространственный результат пригоден для предварительного отбора и постановки следующего исследования.')])
    page('Приложение A. Реестр базовых клубов',[
        table(['№','Клуб','Адрес','Широта; долгота'],[[str(r.id),r['name'],r.address.replace('Москва, ',''),f'{r.lat:.5f}; {r.lon:.5f}'] for _,r in CL.iterrows()],[25,150,200,130]),
        p('Полные ссылки и координатные источники находятся в clubs.csv. Проверка coordinate_audit.csv сопоставляет точки с ближайшими адресными полигонами. Для СССР OSM использует номер 100 без корпуса, для Братеево — 26 к2 вместо официального 26 стр2; эти различия сохранены в аудите. Входы и этажи не проверены на месте.'),
        p('Две записи с неподтверждённой деятельностью (Спорт & Лайф, Winner) и два дополнительных приграничных клуба (МетроFitness, Легион) находятся в supplemental_clubs.csv. Они не добавлены в базовый реестр автоматически.'),
        p('<b>Воспроизводимость.</b> Восемь автоматических тестов проверяют прямой пересчёт выбора и каннибализацию, внешнюю альтернативу, обход барьера и параллельные рёбра, распределение населения, leave-one-out и разнесение зон. На реальных данных дополнительно проверены сохранение спроса, конечность маршрутов, границы прироста сети и неотрицательность модельного regret. Все проверки пройдены.'),
        p('Комплект содержит исходные данные, граф, расстояния, таблицы, карты и код. Скрипт model.py рассчитывает основные результаты; postprocess.py — стресс-тесты реестра и устойчивость; make_deliverables.py — этот отчёт и карту. requirements-lock.txt фиксирует версии проверенной среды. Результаты относятся к сохранённому снимку данных, а не обновляются автоматически.')])
    for start,end in [(0,9),(9,18)]:
        page('Источники и происхождение данных'+(' (продолжение)' if start else ''),[
            p('Веб-источники просмотрены 27.11.2026. Если поисковый снимок содержит более ранний срок действия цены, это отмечено отдельно. Источники адресов не являются наблюдениями клиентского спроса.'),
            *[p(f'<b>[{i+1}] {html.escape(title)}</b><br/>{html.escape(desc)}') for i,(title,desc) in enumerate(sources[start:end],start)]])

def report():
    pdfmetrics.registerFont(TTFont('DV',matplotlib.font_manager.findfont('DejaVu Sans')))
    pdfmetrics.registerFont(TTFont('DV-Bold',matplotlib.font_manager.findfont(matplotlib.font_manager.FontProperties(family='DejaVu Sans',weight='bold'))))
    pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV',boldItalic='DV-Bold')
    styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='BodyRU',fontName='DV',fontSize=9.4,leading=14.2,spaceAfter=10,textColor=colors.HexColor('#23343A'),splitLongWords=True))
    styles.add(ParagraphStyle(name='TitleRU',fontName='DV-Bold',fontSize=21,leading=27,spaceAfter=18,textColor=colors.HexColor(BLUE)))
    styles.add(ParagraphStyle(name='CellRU',fontName='DV',fontSize=8,leading=11,textColor=colors.HexColor('#23343A')))
    styles.add(ParagraphStyle(name='EquationRU',fontName='DV',fontSize=13,leading=19,spaceAfter=13,spaceBefore=5,textColor=colors.HexColor(BLUE)))
    story=[];md=[]
    for title,blocks in pages:
        if story:story.append(PageBreak())
        story.append(Paragraph(title,styles['TitleRU']));md.append('# '+title+'\n')
        for typ,value in blocks:
            if typ in ['p','eq']:
                story.append(Paragraph(value,styles['BodyRU' if typ=='p' else 'EquationRU']))
                md.append(value.replace('<b>','**').replace('</b>','**').replace('<br/>','\n')+'\n')
            elif typ=='img':
                path,height=value
                from PIL import Image as PILImage
                w,h=PILImage.open(path).size;width=min(505,height*w/h);height=width*h/w
                story.extend([Image(path,width=width,height=height),Spacer(1,10)]);md.append(f'![Рисунок](../results/{Path(path).name})\n')
            else:
                headers,rows,widths=value
                cells=[[Paragraph(html.escape(str(t)),styles['CellRU']) for t in row] for row in [headers]+rows]
                tb=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
                tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DFE9E7')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor(BLUE)),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F5F7F5'),colors.white]),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
                story.extend([tb,Spacer(1,12)]);md.extend(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows]+[''])
    def footer(canvas,doc):
        canvas.saveState();canvas.setFont('DV',8);canvas.setFillColor(colors.HexColor(GRAY));canvas.drawString(45,24,'Марьино · пространственная конкуренция · 27.11.2026');canvas.drawRightString(A4[0]-45,24,str(doc.page));canvas.restoreState()
    SimpleDocTemplate(str(OUT/'Marino_Research_Report.pdf'),pagesize=A4,leftMargin=45,rightMargin=45,topMargin=42,bottomMargin=44,title='Пространственная стратегия DDX в Марьино',author='Исследовательский проект по микроэкономике').build(story,onFirstPage=footer,onLaterPages=footer)
    (OUT/'Marino_Research_Report.md').write_text('\n'.join(md),encoding='utf-8')

def interactive_map():
    # Standalone vector display: no remote tiles, scripts, analytics or keys.
    polygons=[]
    for poly in ([boundary] if boundary.geom_type=='Polygon' else boundary.geoms):polygons.append(list(poly.exterior.coords))
    points=C[C.eligible][['x','y','lat','lon','gain_walk','new_walk']].round(6).values.tolist()
    cls=[{'x':r.geometry.x,'y':r.geometry.y,'id':int(r.id),'name':r['name'],'network':r.network} for _,r in clubs.iterrows()]
    data={'boundary':polygons,'points':points,'clubs':cls,'zones':Z[['zone_rank','x','y','nearest_address']].to_dict('records'),'bounds':boundary.bounds}
    template='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Марьино — карта потенциала DDX</title>
<style>body{font:16px system-ui;margin:0;background:#f3f4ef;color:#193f46}main{max-width:1200px;margin:auto;padding:28px}h1{font-size:30px;margin:0 0 12px}.layout{display:grid;grid-template-columns:minmax(0,1fr) 280px;gap:24px}canvas{width:100%;background:white;border:1px solid #c9d3d1}label{display:block;margin:18px 0}input{width:100%}#result{line-height:1.7;background:#fff;padding:16px;min-height:200px}small{color:#53656c}button{padding:8px;margin:5px 0}a{color:#174f59}@media(max-width:800px){.layout{grid-template-columns:minmax(0,1fr)}}</style>
<main><h1>Где искать помещение DDX в Марьино</h1><p>Карта расчётного прироста сети. Наведите курсор или нажмите на точку. Звёзды — три альтернативные зоны; числа — клубы из реестра.</p><div class="layout"><div><canvas id="map" width="1100" height="680"></canvas><small>© OpenStreetMap contributors, ODbL. Координаты проекции EPSG:32637. Снимок 27.11.2026. Север сверху.</small></div><aside><label>Доля клиентов θ: <b id="tv"></b><input id="theta" type="range" min="1" max="10" value="5" step="0.5"></label><label>Маржа в месяц: <b id="mv"></b><input id="margin" type="range" min="300" max="2000" value="1000" step="100"></label><label>Расходы в месяц: <b id="fv"></b><input id="fixed" type="range" min="0" max="3000000" value="500000" step="100000"></label><div id="result"></div></aside></div><p><b>Как читать:</b> цвет показывает географический прирост до умножения на долю клиентов. Ползунки меняют только сценарную экономику. Неизвестны реальные спрос, издержки и наличие подходящих помещений. Результат не является обещанием прибыли.</p><p>Приоритетный ориентир: Братиславская улица, 27 к2. Сетка 50 м. В модели 13 клубов; полнота реестра и продуктовая однородность проверяются отдельными сценариями в отчёте.</p></main>
<script>const D=__DATA__;const cv=document.getElementById('map'),ctx=cv.getContext('2d'),pad=36;let selected=D.points.reduce((a,b)=>a[4]>b[4]?a:b);let [xmin,ymin,xmax,ymax]=D.bounds;D.clubs.forEach(p=>{xmin=Math.min(xmin,p.x);xmax=Math.max(xmax,p.x);ymin=Math.min(ymin,p.y);ymax=Math.max(ymax,p.y)});const scale=Math.min((cv.width-2*pad)/(xmax-xmin),(cv.height-2*pad)/(ymax-ymin));const offx=(cv.width-(xmax-xmin)*scale)/2,offy=(cv.height-(ymax-ymin)*scale)/2;const pos=(x,y)=>[offx+(x-xmin)*scale,cv.height-offy-(y-ymin)*scale];const max=Math.max(...D.points.map(p=>p[4]));function draw(){ctx.clearRect(0,0,cv.width,cv.height);D.boundary.forEach(poly=>{ctx.beginPath();poly.forEach(([x,y],i)=>{const p=pos(x,y);i?ctx.lineTo(...p):ctx.moveTo(...p)});ctx.closePath();ctx.fillStyle='#f0f3ee';ctx.fill();ctx.strokeStyle='#6f8587';ctx.stroke()});D.points.forEach(p=>{const q=pos(p[0],p[1]);const v=p[4]/max;ctx.fillStyle=`hsl(${190-140*v},${25+50*v}%,${88-42*v}%)`;ctx.fillRect(q[0]-2,q[1]-2,4,4)});D.clubs.forEach(c=>{const p=pos(c.x,c.y);ctx.fillStyle=c.network==='DDX'?'#b94f2c':'#1e343c';ctx.beginPath();ctx.arc(...p,4,0,Math.PI*2);ctx.fill();ctx.font='13px sans-serif';ctx.fillText(c.id,p[0]+5,p[1]-5)});D.zones.forEach(z=>{const p=pos(z.x,z.y);ctx.fillStyle='#b64022';ctx.font='24px sans-serif';ctx.fillText('★',p[0]-11,p[1]+8);ctx.font='15px sans-serif';ctx.fillText('Зона '+z.zone_rank,p[0]+13,p[1]-6)});if(selected){let p=pos(selected[0],selected[1]);ctx.strokeStyle='#152d35';ctx.lineWidth=2;ctx.beginPath();ctx.arc(...p,8,0,Math.PI*2);ctx.stroke();ctx.lineWidth=1}}function update(){const t=+document.getElementById('theta').value/100,m=+document.getElementById('margin').value,f=+document.getElementById('fixed').value;const fmt=x=>Math.round(x).toLocaleString('ru-RU');document.getElementById('tv').textContent=(t*100)+'%';document.getElementById('mv').textContent=fmt(m)+' ₽';document.getElementById('fv').textContent=fmt(f)+' ₽';const p=selected;document.getElementById('result').innerHTML=`<b>${p[2].toFixed(6)}, ${p[3].toFixed(6)}</b><br>Прирост сети: ${fmt(p[4])} экв. жителей<br>Условные клиенты: ${fmt(t*p[4])}<br>Каннибализация: ${(p[5]>0?100*(1-p[4]/p[5]):0).toFixed(1)}%<br><b>Сценарная ΔΠ: ${fmt(t*m*p[4]-f)} ₽/мес.</b><br>Порог расходов: ${fmt(t*m*p[4])} ₽/мес.<br><a target="_blank" rel="noreferrer" href="https://www.openstreetmap.org/?mlat=${p[2]}&mlon=${p[3]}#map=17/${p[2]}/${p[3]}">Открыть координаты на OSM</a>`;draw()}function hover(e){const r=cv.getBoundingClientRect(),x=(e.clientX-r.left)*cv.width/r.width,y=(e.clientY-r.top)*cv.height/r.height;let best=null,dist=Infinity;D.points.forEach(p=>{const q=pos(p[0],p[1]),d=(q[0]-x)**2+(q[1]-y)**2;if(d<dist){best=p;dist=d}});if(dist<250){selected=best;update()}}cv.addEventListener('mousemove',hover);cv.addEventListener('click',hover);document.querySelectorAll('input').forEach(i=>i.addEventListener('input',update));update();</script></html>'''
    (OUT/'Marino_Interactive_Map.html').write_text(template.replace('__DATA__',json.dumps(data,ensure_ascii=False)),encoding='utf-8')

def notes():
    text='''# Защита проекта: план на 15 минут

1. Вопрос и ответ — 1 минута. Выбираем новый клуб DDX, оцениваем прирост всей сети. Приоритет — зона Братиславской улицы, 27 к2. Точные координаты — опорная точка, а не доступное помещение.
2. Карта и рынок — 1,5 минуты. 13 клубов, 10 брендов, 9 точек внутри района. Одинаковые цены и качество — упрощение; бассейны и малые форматы выделены в сценарии.
3. Теория — 2 минуты. Полезность с транспортными издержками; ближайший клуб; сеть как единый игрок. ΔΠ = θmΔD − F. Объяснить, почему спрос нового клуба не всегда равен приросту сети.
4. Данные и маршруты — 1,5 минуты. 365 домов, площадь × этажность, население как масштаб. 98 748 узлов OSM, буфер 3 км; кратчайшие пути и прямой доступ к графу.
5. Результат — 1,5 минуты. Братиславская, Перервинский, запад Новочеркасского. Три альтернативы одного открытия, не три суммируемых проекта.
6. Экономика — 1,5 минуты. 42 846 эквивалентов жителей; при 5% — около 2 142 клиентов. Порог расходов 2,14 млн ₽/месяц при марже 1 000 ₽. В осторожном сценарии прибыль отрицательна.
7. Проверка — 2 минуты. LOO по 9 точкам: 929 м против 824 м для евклидовой модели и 1 792 м для случайного выбора. Не скрывать отсутствие победы пешеходной метрики.
8. Устойчивость — 1,5 минуты. 13 спецификаций; первая зона сохраняет минимум 90,8% максимума. Неподтверждённый Спорт & Лайф меняет лидера, но не разрушает потенциал базовой зоны.
9. Рекомендации и ограничения — 1,5 минуты. Найти реальные помещения, уточнить спрос/вместимость/издержки и пересчитать. Пока не утверждать инвестиционную окупаемость, не рекомендовать закрывать существующие клубы.

# Вопросы жюри и ответы

**Это равновесие Хотеллинга?** Нет. Это дискретная задача наилучшего ответа сети при фиксированных локациях и одинаковом продукте. Не найдены совместное равновесие входа и цен или ответы конкурентов.

**Откуда 5%?** Это условная доля потенциальных клиентов, а не оценённый параметр. Она нужна для сценарной экономики. При постоянных марже и расходах по локациям она не меняет ранжирование точек.

**Почему не взять максимальный спрос нового клуба?** Часть клиентов может перейти из собственных клубов. Для сети важен чистый прирост. В базовой выбранной точке каннибализация равна нулю именно в данной модели, но это не общее свойство рынка.

**Почему пешеходная модель хуже евклидовой в LOO?** Точнее измерить путь не означает лучше описать весь выбор. Нет потока ТЦ и метро, цен, бренда, вместимости и истории размещения. Девять точек дают ограниченный материал для проверки.

**Вы предлагаете открыть клуб в жилом доме?** Нет. Адрес — ближайший ориентир. Сетка не содержит информации о вакантных помещениях. Рекомендация — зона поиска; каждое помещение нужно оценивать отдельно.

**Почему у маленькой Академии спорта такая большая доля?** Это свидетельство ограничения модели без вместимости. Поэтому сценарий исключения компактных залов обязателен, и западная альтернатива признана менее устойчивой.

**HHI показывает слабую концентрацию?** Он посчитан по условным зонам спроса, не по продажам. Его можно использовать для описания модельного распределения, но не как установленную характеристику фактической концентрации.

**А если пропущен конкурент?** Для этого добавлены две неподтверждённые и две приграничные записи. Изменение ранга прямо показано. Полнота рынка не считается доказанной.

**Можно сложить эффекты трёх зон?** Нет, после каждого нового клуба меняются зоны обслуживания. Здесь три альтернативы для одного открытия.

**Почему нет точной окупаемости?** Нет фактических аренды, капитальных затрат, спроса и маржи. Вместо выдуманных затрат рассчитаны пороги безубыточности и условия решения.
'''
    (OUT/'Defense_Notes_RU.md').write_text(text,encoding='utf-8')

if __name__=='__main__':
    figures();content();report();interactive_map();notes();print('Created',len(pages),'report sections')
