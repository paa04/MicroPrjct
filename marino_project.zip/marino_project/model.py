"""Spatial competition: all distances in metres; demand from Marino residents only."""
from pathlib import Path
import argparse, json, re, time
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from scipy.sparse.csgraph import dijkstra
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parent
CRS = 'EPSG:32637'

def shares(dist, networks, weights, target, candidates, max_distance=np.inf):
    """Equal splitting of exact/near ties, including co-locations. Arrays CxN and HxN."""
    nearest = dist.min(axis=0)
    ties = np.isclose(dist, nearest, atol=1e-6, rtol=0) & np.isfinite(dist) & (dist<=max_distance)
    count = ties.sum(axis=0)
    safe_count=np.maximum(count,1)
    own = (ties[networks == target].sum(axis=0) / safe_count)
    new=np.empty(len(candidates)); gained=np.empty(len(candidates))
    for i in range(0,len(candidates),128):
        block=candidates[i:i+128]
        better=block < nearest[None,:]-1e-6
        equal=np.isclose(block,nearest[None,:],atol=1e-6,rtol=0)
        pnew=(better.astype(float)+equal/(count+1)) * (block<=max_distance) * np.isfinite(block)
        new[i:i+len(block)]=pnew @ weights
        gained[i:i+len(block)]=pnew @ (weights*(1-own))
    return new,gained,float(own @ weights),(ties/safe_count) @ weights

def choose(score, eligible):
    a = np.flatnonzero(eligible & np.isfinite(score))
    if not len(a): raise ValueError('No eligible candidate')
    return a[np.argmax(score[a])]

def validation(Dc, Dh, E_c, E_h, club_xy, cand_xy, weights, uniform, UEc, UEh, nets, in_district, grid_count, pop_score, min_sep):
    records=[]
    for i in np.flatnonzero(in_district):
        keep=np.arange(len(nets))!=i
        # All methods share the grid and the held-out actual site, not other observed sites.
        ids=np.r_[np.arange(grid_count),grid_count+i]
        eligible=(cdist(cand_xy[ids],club_xy[keep]).min(axis=1)>=min_sep)
        eligible[-1]=True # observed site must be comparable even if close to another club
        actual=len(ids)-1
        dist_error=np.linalg.norm(cand_xy[ids]-club_xy[i],axis=1)
        new,gain,_,_=shares(Dc[keep],nets[keep],weights,nets[i],Dh[ids])
        _,g_e,_,_=shares(E_c[keep],nets[keep],weights,nets[i],E_h[ids])
        _,g_u,_,_=shares(UEc[keep],nets[keep],uniform,nets[i],UEh[ids])
        options={'population_500m':pop_score[ids], 'farthest_club':cdist(cand_xy[ids],club_xy[keep]).min(axis=1),
                 'uniform_euclidean_network':g_u,'population_euclidean_network':g_e,
                 'population_walk_single_club':new,'population_walk_network':gain}
        # Random benchmark is the exact expected score over eligible candidates.
        max_gain=float(gain[eligible].max())
        records.append(dict(club_index=i,method='random_expected',error_m=float(dist_error[eligible].mean()),
                            missed_resident_equivalents=float(max_gain-gain[eligible].mean()),actual_percentile=np.nan,
                            pred_x=np.nan,pred_y=np.nan,actual_x=club_xy[i,0],actual_y=club_xy[i,1]))
        for method,score in options.items():
            k=choose(score,eligible)
            percentile=100*((score[eligible]<score[actual]-1e-8).sum()+0.5*np.isclose(score[eligible],score[actual],atol=1e-8,rtol=0).sum())/eligible.sum()
            maxima=eligible & np.isclose(score,score[k],atol=1e-8,rtol=0)
            records.append(dict(club_index=i,method=method,error_m=float(dist_error[k]),
                                tied_maxima=int(maxima.sum()),tie_min_error_m=float(dist_error[maxima].min()),tie_max_error_m=float(dist_error[maxima].max()),
                                actual_regret=float(max_gain-gain[actual]),
                                missed_resident_equivalents=float(max_gain-gain[k]),actual_percentile=percentile,
                                pred_x=cand_xy[ids[k],0],pred_y=cand_xy[ids[k],1],actual_x=club_xy[i,0],actual_y=club_xy[i,1]))
    return pd.DataFrame(records)

def points_xy(g):
    return np.column_stack([g.x,g.y])

def load_geo(args, cache):
    import geopandas as gpd, osmnx as ox
    from shapely.geometry import Point
    ox.settings.use_cache=True
    ox.settings.cache_folder=cache/'http'
    ox.settings.requests_timeout=180
    ox.settings.http_user_agent='MarinoNESAcademicProject/1.0'
    bp=cache/'boundary.geojson'
    if bp.exists(): b=gpd.read_file(bp).to_crs(CRS)
    else:
        b=ox.geocode_to_gdf('район Марьино, Москва, Россия').to_crs(CRS)
        if not b.geometry.iloc[0].geom_type in ('Polygon','MultiPolygon'): raise ValueError('Invalid district boundary')
        if not 5e6 < b.geometry.iloc[0].area < 30e6: raise ValueError('Check district boundary: unexpected area')
        b.to_crs(4326).to_file(bp,driver='GeoJSON')
    boundary=b.geometry.iloc[0]
    if not 5e6 < boundary.area < 30e6: raise ValueError('Check cached district boundary')
    polygon=gpd.GeoSeries([boundary.buffer(args.buffer)],crs=CRS).to_crs(4326).iloc[0]
    buildings_path=cache/'buildings.geojson'
    if buildings_path.exists(): buildings=gpd.read_file(buildings_path).to_crs(CRS)
    else:
        raw=ox.features_from_polygon(b.to_crs(4326).geometry.iloc[0],tags={'building':True}).to_crs(CRS)
        raw=raw[raw.geometry.geom_type.isin(['Polygon','MultiPolygon'])].copy()
        raw=raw[raw.geometry.representative_point().within(boundary)]
        raw=raw[raw['building'].isin(['apartments','residential','house','detached','semidetached_house','terrace','dormitory'])].copy()
        if raw.empty: raise ValueError('No residential buildings found')
        buildings=raw[['building','geometry']+[c for c in ['building:levels'] if c in raw.columns]].reset_index()
        buildings=buildings.rename(columns={'id':'osm_id'})
        buildings.to_crs(4326).to_file(buildings_path,driver='GeoJSON')
    graph_path=cache/f'walk_{float(args.buffer)}.graphml'
    if graph_path.exists(): G=ox.load_graphml(graph_path)
    else:
        G=ox.graph_from_polygon(polygon,network_type='walk',retain_all=False,simplify=False)
        G=ox.project_graph(G,to_crs=CRS)
        ox.save_graphml(G,graph_path)
    if str(G.graph['crs'])!=CRS: G=ox.project_graph(G,to_crs=CRS)
    return boundary,buildings,G

def load_clubs(args,cache,boundary):
    import geopandas as gpd, osmnx as ox
    table=pd.read_csv(args.clubs)
    table=table[(table.include==1)&(table.status!='closed')].copy()
    if args.official_only: table=table[table.status=='official'].copy()
    gp=cache/'geocodes.csv'
    geo=pd.read_csv(gp) if gp.exists() else pd.DataFrame(columns=['address','lat','lon'])
    for idx,row in table.iterrows():
        if pd.notna(row.lat) and pd.notna(row.lon): continue
        hit=geo[geo.address==row.address]
        if len(hit): lat,lon=hit.iloc[-1][['lat','lon']]
        else:
            time.sleep(1.1)
            try:
                # Query full address, not name; manual coordinates override geocoder.
                lat,lon=ox.geocode(row.address+', Россия')
            except Exception as e: raise RuntimeError(f'Cannot geocode {row.address}; fill lat/lon in clubs.csv') from e
            geo=pd.concat([geo,pd.DataFrame([dict(address=row.address,lat=lat,lon=lon)])],ignore_index=True)
            geo.to_csv(gp,index=False)
        table.loc[idx,['lat','lon']]=[lat,lon]
    clubs=gpd.GeoDataFrame(table,geometry=gpd.points_from_xy(table.lon,table.lat),crs=4326).to_crs(CRS)
    clubs['in_district']=clubs.geometry.within(boundary)
    clubs['distance_to_district_m']=clubs.geometry.distance(boundary)
    if (clubs.distance_to_district_m>15000).any(): raise ValueError('Geocoding error: a club is very far away; inspect geocodes.csv')
    clubs=clubs[clubs.distance_to_district_m<=args.buffer].reset_index(drop=True)
    if len(clubs)<2: raise ValueError('Not enough clubs')
    return clubs

def prepare_buildings(buildings,boundary,population):
    g=buildings.copy()
    g=g[g.geometry.representative_point().within(boundary)].copy()
    # Ignore tiny geometries and avoid counting building parts as separate houses.
    g['footprint_m2']=g.geometry.area
    g=g[g.footprint_m2>=30].copy()
    if g.empty: raise ValueError('No buildings after filtering')
    raw=g.get('building:levels',pd.Series(np.nan,index=g.index))
    levels=pd.to_numeric(raw.astype(str).str.extract(r'^\s*(\d+(?:\.\d+)?)\s*$')[0],errors='coerce')
    levels=levels.where(levels.between(1,80))
    g['levels_observed']=levels.notna()
    median=levels.groupby(g.building).transform('median')
    defaults=g.building.map({'apartments':9,'residential':9,'dormitory':5,'house':2,'detached':2,'semidetached_house':2,'terrace':2}).fillna(5)
    g['levels']=levels.fillna(median).fillna(defaults)
    g['floor_proxy']=g.footprint_m2*g.levels
    g['residents']=population*g.floor_proxy/g.floor_proxy.sum()
    g.geometry=g.geometry.representative_point()
    return g.reset_index(drop=True)

def make_grid(boundary,step):
    import shapely
    x0,y0,x1,y1=boundary.bounds
    xy=np.array(np.meshgrid(np.arange(x0,x1,step),np.arange(y0,y1,step))).reshape(2,-1).T
    return xy[shapely.contains_xy(boundary,xy[:,0],xy[:,1])]

def graph_distances(G, source_xy, demand_xy, batch=32):
    """Shortest walking graph distance plus straight-line access to snapped nodes."""
    from scipy.spatial import cKDTree
    nodes=list(G.nodes); index={n:i for i,n in enumerate(nodes)}
    xy=np.array([(G.nodes[n]['x'],G.nodes[n]['y']) for n in nodes])
    tree=cKDTree(xy)
    off_s,idx_s=tree.query(source_xy); off_d,idx_d=tree.query(demand_xy)
    edges={}
    for a,b,attrs in G.edges(data=True):
        i,j=index[a],index[b]; w=float(attrs['length'])
        # Walking graph is treated as bidirectional; parallel edges use minimum length.
        if i!=j:
            edges[i,j]=min(w,edges.get((i,j),np.inf)); edges[j,i]=min(w,edges.get((j,i),np.inf))
    ij=np.array(list(edges)); vals=np.array(list(edges.values()))
    mat=coo_matrix((vals,(ij[:,0],ij[:,1])),shape=(len(nodes),len(nodes))).tocsr()
    unique,inv=np.unique(idx_s,return_inverse=True)
    out=np.empty((len(unique),len(demand_xy)),np.float64)
    for start in range(0,len(unique),batch):
        u=unique[start:start+batch]
        out[start:start+len(u)]=dijkstra(mat,directed=True,indices=u)[:,idx_d]
    return out[inv]+off_s[:,None]+off_d[None,:],off_s,off_d

def render(out,boundary,buildings,clubs,candidates,target,best,grid_count,valid,graph=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import geopandas as gpd
    from matplotlib.colors import Normalize
    def base():
        fig,ax=plt.subplots(figsize=(10,8),layout='constrained')
        gpd.GeoSeries([boundary],crs=CRS).boundary.plot(ax=ax,color='black',linewidth=1)
        if graph is not None:
            import osmnx as ox
            ox.graph_to_gdfs(graph,nodes=False).clip(boundary).plot(ax=ax,color='#cbd5e1',linewidth=.25,alpha=.5)
        ax.set_aspect('equal'); ax.set_xlabel('Easting (m)'); ax.set_ylabel('Northing (m)'); fig.text(.99,.005,'© OpenStreetMap contributors',ha='right',fontsize=8)
        return fig,ax
    def marks(ax):
        for own,label,color in [(False,'Other clubs','#30343b'),(True,target,'#2166ac')]:
            subset=clubs[(clubs.network==target)==own]
            ax.scatter(subset.geometry.x,subset.geometry.y,c=color,s=36,edgecolors='white',linewidths=.5,label=label,zorder=4)
        ax.legend(loc='best',fontsize=8)
    fig,ax=base(); p=ax.scatter(buildings.geometry.x,buildings.geometry.y,c=buildings.residents,s=9,cmap='viridis'); fig.colorbar(p,ax=ax,label='Estimated residents per building'); marks(ax); ax.set_title('Marino: residential demand proxy'); fig.savefig(out/'01_demand.png',dpi=180); plt.close(fig)
    fig,ax=base();
    for net,sub in buildings.groupby('nearest_network'):
        ax.scatter(sub.geometry.x,sub.geometry.y,s=7,label=net,alpha=.8)
    ax.legend(fontsize=7,loc='best'); ax.set_title('Walking-distance catchments (dominant assignment)'); fig.savefig(out/'02_catchments.png',dpi=180); plt.close(fig)
    eligible=candidates.iloc[:grid_count]; eligible=eligible[eligible.eligible]
    for col,name,title,unit in [('gain_walk','03_gain','Incremental network demand','Resident equivalents'),('profit_month','04_profit','Illustrative incremental monthly profit','RUB/month'),('gain_euclidean','05_euclidean','Incremental demand: straight-line distance','Resident equivalents')]:
        fig,ax=base(); p=ax.scatter(eligible.x,eligible.y,c=eligible[col],s=22,marker='s',cmap='viridis'); fig.colorbar(p,ax=ax,label=unit); marks(ax); ax.scatter(best.x,best.y,marker='*',s=190,c='#ed553b',edgecolors='black',label='Walking optimum',zorder=5); ax.legend(fontsize=8); ax.set_title(title); fig.savefig(out/f'{name}.png',dpi=180); plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,5),layout='constrained'); s=valid.groupby('method').error_m.mean().sort_values(); s.plot.barh(ax=ax,color='#3877a6'); ax.set_xlabel('Mean location error (m)'); ax.set_title('Leave-one-out: current-location consistency'); fig.savefig(out/'06_validation.png',dpi=180); plt.close(fig)

def run(args):
    import geopandas as gpd
    cache=Path(args.cache); cache.mkdir(parents=True,exist_ok=True)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    print('Loading cached geography...',flush=True)
    boundary,raw,G=load_geo(args,cache)
    clubs=load_clubs(args,cache,boundary)
    buildings=prepare_buildings(raw,boundary,args.population)
    print(f'{len(buildings)} buildings, {len(clubs)} clubs, {len(G)} graph nodes',flush=True)
    x=points_xy(buildings.geometry); c=points_xy(clubs.geometry); grid=make_grid(boundary,args.step)
    all_sources=np.vstack([grid,c]); D,offset_s,offset_d=graph_distances(G,all_sources,x)
    print(f'Calculated pedestrian distances for {len(grid)} grid points',flush=True)
    # Exclude very distant candidate snaps; fail rather than silently dropping residents/clubs.
    if (offset_s[len(grid):]>300).any() or (offset_d>300).any(): raise ValueError('A club/building is >300 m from the walking graph; inspect OSM coverage and geocodes')
    if not np.isfinite(D).all(): raise ValueError('Disconnected distances: inspect walking graph')
    eligible_snap=offset_s[:len(grid)]<=args.max_snap
    grid=grid[eligible_snap]; Dh=np.vstack([D[:len(eligible_snap)][eligible_snap],D[len(eligible_snap):]])
    if not len(grid): raise ValueError('No grid candidates after graph snapping')
    H=len(grid); cand=np.vstack([grid,c]); Dc=Dh[H:]; E_c=cdist(c,x); E_h=cdist(cand,x)
    w=buildings.residents.to_numpy(); nets=clubs.network.to_numpy()
    if args.target not in nets: raise ValueError('Target network not in included clubs')
    # Uniform land-area baseline: equal weights at 100m district lattice, not equal per building.
    uxy=make_grid(boundary,100); UEc=cdist(c,uxy); UEh=cdist(cand,uxy)
    uniform=np.full(len(uxy),args.population/len(uxy))
    new,gain,base,q=shares(Dc,nets,w,args.target,Dh); _,gain_e,_,q_e=shares(E_c,nets,w,args.target,E_h)
    eligible=np.r_[cdist(grid,c).min(axis=1)>=args.min_sep,np.zeros(len(c),bool)]
    p=args.participation; margin=args.margin; fixed=args.fixed_cost
    profit=p*margin*gain-fixed
    k=choose(profit,eligible)
    loc=gpd.GeoSeries(gpd.points_from_xy(cand[:,0],cand[:,1]),crs=CRS).to_crs(4326)
    cand_df=pd.DataFrame(dict(x=cand[:,0],y=cand[:,1],lat=loc.y,lon=loc.x,eligible=eligible,source=['grid']*H+['existing']*len(c),new_walk=new,gain_walk=gain,gain_euclidean=gain_e,profit_month=profit,break_even_fixed_month=p*margin*gain,scenario_new_members=p*new,scenario_incremental_members=p*gain,cannibalization=np.divide(new-gain,new,out=np.zeros_like(new),where=new>0)))
    cand_df.to_csv(out/'candidates.csv',index=False)
    cand_df[eligible].sort_values('profit_month',ascending=False).head(30).to_csv(out/'top30.csv',index=False)
    clubs['demand_walk']=q; clubs['demand_euclidean']=q_e; clubs['share_walk']=q/w.sum()
    clubs.to_crs(4326).to_file(out/'clubs.geojson',driver='GeoJSON'); clubs.drop(columns='geometry').to_csv(out/'club_demand.csv',index=False)
    buildings['nearest_network']=nets[Dc.argmin(axis=0)]
    buildings['nearest_walk_min']=Dc.min(axis=0)/80.0
    buildings.to_crs(4326).to_file(out/'demand.geojson',driver='GeoJSON')
    pop_score=(E_h<=500)@w
    valid=validation(Dc,Dh,E_c,E_h,c,cand,w,uniform,UEc,UEh,nets,clubs.in_district.to_numpy(),H,pop_score,args.min_sep)
    if valid.empty: raise ValueError('No existing clubs within district for validation')
    valid['club']=clubs.name.to_numpy()[valid.club_index.to_numpy()]
    valid.to_csv(out/'loo.csv',index=False)
    valid.groupby('method').agg(n=('error_m','size'),mean_error_m=('error_m','mean'),median_error_m=('error_m','median'),mean_missed_resident_equivalents=('missed_resident_equivalents','mean'),mean_percentile=('actual_percentile','mean')).to_csv(out/'loo_summary.csv')
    network=clubs.groupby('network')[['demand_walk','demand_euclidean']].sum(); network['share_walk']=network.demand_walk/w.sum(); network.to_csv(out/'network_shares.csv')
    result=dict(target=args.target,population=args.population,buildings=len(buildings),observed_levels_fraction=float(buildings.levels_observed.mean()),clubs=len(clubs),grid_candidates=H,eligible_candidates=int(eligible.sum()),base_resident_equivalents=base,walking_speed_kmh_assumption=4.8,participation_scenario=p,monthly_margin_scenario=margin,monthly_fixed_cost_scenario=fixed,best=cand_df.iloc[k].to_dict(),hhi_walk=float(10000*(network.share_walk**2).sum()),max_demand_snap_m=float(offset_d.max()),entry_profitable_in_scenario=bool(profit[k]>0),notes='Resident-origin demand only; no outside option, capacities or differentiated prices. Scenario, not observed profit.')
    (out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda v:v.item()),encoding='utf-8')
    from robustness import analyze
    analyze(out,args,buildings,clubs,cand_df,Dc,Dh,E_c,E_h,k)
    render(out,boundary,buildings,clubs,cand_df,args.target,cand_df.iloc[k],H,valid,G)
    print(json.dumps(result,ensure_ascii=False,indent=2,default=lambda v:v.item()))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--clubs',default=str(ROOT/'clubs.csv')); parser.add_argument('--cache',default=str(ROOT/'cache')); parser.add_argument('--out',default=str(ROOT/'results'))
    parser.add_argument('--target',default='DDX'); parser.add_argument('--population',type=float,default=273463); parser.add_argument('--step',type=float,default=50); parser.add_argument('--buffer',type=float,default=3000); parser.add_argument('--max-snap',type=float,default=100); parser.add_argument('--min-sep',type=float,default=50)
    parser.add_argument('--participation',type=float,default=.05); parser.add_argument('--margin',type=float,default=1000); parser.add_argument('--fixed-cost',type=float,default=500000); parser.add_argument('--official-only',action='store_true')
    a=parser.parse_args()
    if not 0<a.participation<=1 or a.margin<=0 or a.fixed_cost<0 or a.step<=0 or a.buffer<=0 or a.population<=0 or a.max_snap<=0 or a.min_sep<0: parser.error('Invalid model parameters')
    run(a)
