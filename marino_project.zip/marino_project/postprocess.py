"""Run after model.py: source updates, registry stress tests and geographic labels."""
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import osmnx as ox
from shapely.geometry import Point
from model import shares, graph_distances, points_xy, CRS
from robustness import analyze

ROOT=Path(__file__).resolve().parent

def main(out=None):
    out=Path(out or ROOT/'results');cache=ROOT/'cache'
    summary=json.loads((out/'summary.json').read_text());m=np.load(out/'distance_matrices.npz')
    candidates=pd.read_csv(out/'candidates.csv');eligible=candidates.eligible.to_numpy();best_index=candidates[eligible].gain_walk.idxmax()
    clubs=gpd.read_file(out/'clubs.geojson').to_crs(CRS);b=gpd.read_file(out/'demand.geojson').to_crs(CRS)
    latest=pd.read_csv(ROOT/'clubs.csv').set_index('id')
    for col in ['status','source','notes']:clubs[col]=clubs.id.map(latest[col])
    clubs.to_crs(4326).to_file(out/'clubs.geojson',driver='GeoJSON');clubs.drop(columns='geometry').to_csv(out/'club_demand.csv',index=False)
    args=SimpleNamespace(target=summary['target'],population=summary['population'],step=50 if len(candidates)>2000 else 100)
    analyze(out,args,b,clubs,candidates,m['Dc'],m['Dh'],m['E_c'],m['E_h'],best_index)
    G=ox.load_graphml(cache/'walk_3000.0.graphml')
    extra=pd.read_csv(ROOT/'supplemental_clubs.csv')
    extra_geo=gpd.GeoDataFrame(extra,geometry=gpd.points_from_xy(extra.lon,extra.lat),crs=4326).to_crs(CRS)
    ext,offs,_=graph_distances(G,points_xy(extra_geo.geometry),points_xy(b.geometry))
    if np.max(offs)>300:raise ValueError('Supplemental club snap exceeds 300m')
    nets=clubs.network.to_numpy();w=m['weights'];rows=[];scores=pd.read_csv(out/'sensitivity_scores.csv');zones=pd.read_csv(out/'priority_zones.csv')
    for label,keep in [('add_border',extra.group=='border'),('add_sportlife',extra.id==20),('add_uncertain',extra.group=='uncertain'),('add_all_four',np.ones(len(extra),bool))]:
        dc=np.vstack([m['Dc'],ext[keep]]);net=np.concatenate([nets,extra.loc[keep,'network'].to_numpy()])
        new,gain,base,q=shares(dc,net,w,args.target,m['Dh'])
        valid=eligible.copy()
        from scipy.spatial.distance import cdist
        valid &= cdist(candidates[['x','y']],points_xy(extra_geo.geometry)[keep]).min(axis=1)>=50
        ids=np.flatnonzero(valid);k=ids[np.argmax(gain[ids])];top=gain[k];site=candidates.iloc[k];baseline=candidates.iloc[best_index]
        rows.append(dict(specification=label,clubs=len(net),best_lat=site.lat,best_lon=site.lon,best_gain=top,
            baseline_site_gain=gain[best_index],baseline_retention_pct=100*gain[best_index]/top,
            shift_m=np.hypot(site.x-baseline.x,site.y-baseline.y),base_network_demand=base,covered_residents=q.sum(),best_candidate_index=int(k)))
        scores[label]=gain
        for iz,z in zones.iterrows():
            match=np.flatnonzero(np.isclose(candidates.x,z.x)&np.isclose(candidates.y,z.y))
            # Exact source coordinates are retained across CSV round trips.
            match=np.flatnonzero((abs(candidates.x-z.x)<1e-6)&(abs(candidates.y-z.y)<1e-6))
            zones.loc[iz,label+'_retention_pct']=100*gain[match[0]]/top
    pd.concat([pd.read_csv(out/'sensitivity.csv'),pd.DataFrame(rows)],ignore_index=True).to_csv(out/'sensitivity.csv',index=False)
    scores.to_csv(out/'sensitivity_scores.csv',index=False)
    common=eligible & (cdist(candidates[['x','y']],points_xy(extra_geo.geometry)).min(axis=1)>=50)
    normalized=scores/scores.loc[common].max(axis=0)
    robust=normalized.min(axis=1)
    rid=robust[common].idxmax()
    selected=candidates.loc[rid].to_dict()
    selected['worst_retention_pct']=float(100*robust[rid])
    selected['base_optimum_worst_retention_pct']=float(100*robust[best_index])
    selected['robust_candidate_index']=int(rid)
    selected['scenario_retention_pct']=(100*normalized.loc[rid]).to_dict()
    address=gpd.read_file(cache/'address_buildings.geojson').to_crs(CRS)
    address=address[address.address.str.contains(r',\s*\S',regex=True)].copy()
    d=address.geometry.distance(Point(selected['x'],selected['y']))
    selected['nearest_address']=address.loc[d.idxmin(),'address']
    selected['address_distance_m']=float(d.min())
    (out/'robust_choice.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2,default=lambda v:v.item()),encoding='utf-8')
    for iz,z in zones.iterrows():
        d=address.geometry.distance(Point(z.x,z.y));r=address.loc[d.idxmin()]
        zones.loc[iz,'nearest_address']=r.address;zones.loc[iz,'address_distance_m']=d.min()
    zones.to_csv(out/'priority_zones.csv',index=False)
    old=ROOT/'results_grid100/summary.json'
    if old.exists():
        s100=json.loads(old.read_text());p100=s100['best'];p50=summary['best']
        comparison=dict(step100_gain=p100['gain_walk'],step50_gain=p50['gain_walk'],gain_improvement_pct=100*(p50['gain_walk']/p100['gain_walk']-1),shift_m=float(np.hypot(p100['x']-p50['x'],p100['y']-p50['y'])))
        (out/'grid_convergence.json').write_text(json.dumps(comparison,indent=2))
    # Validation invariants on actual data, independent of map rendering.
    assert abs(w.sum()-summary['population'])<1e-5
    transfers=pd.read_csv(out/'demand_transfers.csv')
    assert abs(transfers.change_residents.sum())<1e-5
    assert (candidates.gain_walk>=-1e-8).all()
    assert (candidates.new_walk>=candidates.gain_walk-1e-8).all()
    assert np.isfinite(m['Dc']).all() and np.isfinite(m['Dh']).all()
    assert (pd.read_csv(out/'loo.csv').missed_resident_equivalents>=-1e-5).all()
    (out/'empirical_checks.json').write_text(json.dumps({'population_conserved':True,'counterfactual_demand_conserved':True,'network_gain_bounds':True,'finite_routes':True,'nonnegative_loo_regret':True},indent=2))
    print(pd.read_csv(out/'sensitivity.csv').to_string(index=False));print(zones[['zone_rank','nearest_address','gain_walk']].to_string(index=False))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',default=str(ROOT/'results'));main(p.parse_args().out)
