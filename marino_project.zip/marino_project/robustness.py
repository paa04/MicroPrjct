"""Sensitivity and decision summaries from the same cached empirical distances."""
from itertools import product
import json
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from model import shares

def separated_zones(table, n=3, separation=500):
    selected=[]
    for idx,row in table[table.eligible].sort_values('gain_walk',ascending=False,kind='stable').iterrows():
        if all(np.hypot(row.x-table.loc[j,'x'],row.y-table.loc[j,'y'])>=separation for j in selected):selected.append(idx)
        if len(selected)==n:break
    result=table.loc[selected].copy();result.insert(0,'zone_rank',np.arange(1,len(result)+1))
    return result

def analyze(out,args,buildings,clubs,cand,Dc,Dh,E_c,E_h,best_index):
    nets=clubs.network.to_numpy();w=buildings.residents.to_numpy();eligible=cand.eligible.to_numpy()
    baseline=cand.iloc[best_index];rows=[];score_columns={}
    specifications=[('base_walk',Dc,Dh,w,np.ones(len(clubs),bool),np.inf),
        ('straight_line',E_c,E_h,w,np.ones(len(clubs),bool),np.inf),
        ('footprint_only',Dc,Dh,args.population*buildings.footprint_m2.to_numpy()/buildings.footprint_m2.sum(),np.ones(len(clubs),bool),np.inf),
        ('walk_15min',Dc,Dh,w,np.ones(len(clubs),bool),1200),
        ('walk_20min',Dc,Dh,w,np.ones(len(clubs),bool),1600),
        ('walk_30min',Dc,Dh,w,np.ones(len(clubs),bool),2400),
        ('exclude_terfit',Dc,Dh,w,(clubs.network!='Территория фитнеса').to_numpy(),np.inf),
        ('exclude_pool_clubs',Dc,Dh,w,~clubs.network.isin(['Magneto','СССР','Территория фитнеса','La Salute']).to_numpy(),np.inf),
        ('exclude_compact',Dc,Dh,w,~clubs.network.isin(['XFIT','Академия Спорта']).to_numpy(),np.inf)]
    for name,dc,dh,weights,keep,cutoff in specifications:
        if not keep.any():continue
        new,gain,base,q=shares(dc[keep],nets[keep],weights,args.target,dh,cutoff)
        ids=np.flatnonzero(eligible);k=ids[np.argmax(gain[ids])];top=gain[k]
        score_columns[name]=gain
        rows.append(dict(specification=name,clubs=int(keep.sum()),best_lat=cand.iloc[k].lat,best_lon=cand.iloc[k].lon,
            best_gain=top,baseline_site_gain=gain[best_index],baseline_retention_pct=100*gain[best_index]/top if top else 100,
            shift_m=float(np.hypot(cand.iloc[k].x-baseline.x,cand.iloc[k].y-baseline.y)),
            base_network_demand=base,covered_residents=float(q.sum()),best_candidate_index=int(k)))
    pd.DataFrame(rows).to_csv(out/'sensitivity.csv',index=False)
    pd.DataFrame(score_columns).to_csv(out/'sensitivity_scores.csv',index=False)
    zones=separated_zones(cand)
    for name,gain in score_columns.items():
        mx=gain[eligible].max()
        zones[name+'_retention_pct']=100*gain[zones.index]/mx if mx else 100
    zones.to_csv(out/'priority_zones.csv',index=False)
    economics=[]
    for theta,margin,fixed in product([.03,.05,.08],[800,1000,1500],[500000,1000000,1500000]):
        economics.append(dict(participation=theta,margin=margin,fixed_month=fixed,
            incremental_members=theta*baseline.gain_walk,profit_month=theta*margin*baseline.gain_walk-fixed,
            break_even_fixed_month=theta*margin*baseline.gain_walk))
    pd.DataFrame(economics).to_csv(out/'economics_scenarios.csv',index=False)
    _,_,_,before=shares(Dc,nets,w,args.target,Dh[:0])
    augmented=np.vstack([Dc,Dh[best_index]])
    allnets=np.concatenate([nets,np.array([args.target])])
    _,_,_,after=shares(augmented,allnets,w,args.target,Dh[:0])
    change=clubs[['id','name','network']].copy()
    change['before_residents']=before;change['after_residents']=after[:-1]
    change['change_residents']=after[:-1]-before
    change=pd.concat([change,pd.DataFrame([dict(id='new',name='New candidate',network=args.target,before_residents=0,after_residents=after[-1],change_residents=after[-1])])],ignore_index=True)
    change.to_csv(out/'demand_transfers.csv',index=False)
    a=Dc.min(axis=0);b=augmented.min(axis=0)
    access=dict(mean_before_min=float(a@w/w.sum()/80),mean_after_min=float(b@w/w.sum()/80),
        share_15min_before=float(w[a<=1200].sum()/w.sum()),share_15min_after=float(w[b<=1200].sum()/w.sum()),
        grid_step_m=args.step,top_95pct_candidates=int((eligible & (cand.gain_walk>=.95*baseline.gain_walk)).sum()),
        modeled_hhi_note='Model resident-origin assignment, not observed membership or revenue shares.')
    (out/'accessibility.json').write_text(json.dumps(access,indent=2),encoding='utf-8')
    # Exact reproducibility of all empirical comparisons, no network needed.
    np.savez_compressed(out/'distance_matrices.npz',Dc=Dc,Dh=Dh,E_c=E_c,E_h=E_h,weights=w,networks=nets.astype(str))
