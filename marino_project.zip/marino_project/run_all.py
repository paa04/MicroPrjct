"""Reproduce the complete fixed-snapshot research package from this directory."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
if __name__ == '__main__':
    for args in [
        ['-m', 'unittest', '-v'],
        ['model.py', '--step', '100', '--out', 'results_grid100'],
        ['model.py', '--step', '50', '--out', 'results'],
        ['postprocess.py'],
        ['make_deliverables.py'],
    ]:
        subprocess.run([sys.executable, *args], cwd=ROOT, check=True)
