import unittest
import numpy as np
import networkx as nx
from scipy.spatial.distance import cdist
from model import shares, graph_distances, validation

class ModelTests(unittest.TestCase):
    def test_against_brute_force(self):
        rng=np.random.default_rng(42)
        D=rng.integers(1,8,(6,40)).astype(float)
        H=rng.integers(1,8,(11,40)).astype(float)
        nets=np.array(['A','B','A','C','B','A']); w=rng.integers(1,20,40)
        new,gain,base,q=shares(D,nets,w,'A',H)
        self.assertAlmostEqual(q.sum(),w.sum())
        for k,row in enumerate(H):
            X=np.vstack([D,row]); tie=X==X.min(axis=0); probs=tie/tie.sum(axis=0)
            q2=probs@w
            self.assertAlmostEqual(new[k],q2[-1])
            self.assertAlmostEqual(gain[k],q2[np.r_[nets=='A',True]].sum()-base)
            self.assertLessEqual(gain[k],new[k]+1e-8)
    def test_same_network_cannibalization(self):
        D=np.array([[5.,3.],[9.,1.]]); w=np.array([100.,200.]); nets=np.array(['A','B'])
        n,g,b,_=shares(D,nets,w,'A',np.array([[2.,2.],[6.,.5]]))
        np.testing.assert_allclose(n,[100,200]); np.testing.assert_allclose(g,[0,200]); self.assertEqual(b,100)
    def test_route_barrier(self):
        G=nx.MultiDiGraph()
        for i,(x,y) in enumerate([(0,0),(0,100),(100,100),(100,0)]): G.add_node(i,x=x,y=y)
        for i in range(3): G.add_edge(i,i+1,length=100)
        D,a,b=graph_distances(G,np.array([[0,0],[100,0]]),np.array([[100,0]]))
        np.testing.assert_allclose(D[:,0],[300,0])
    def test_validation(self):
        c=np.array([[0.,0.],[10.,0.],[20.,0.]])
        x=np.array([[1.,0.],[9.,0.],[15.,0.]])
        grid=np.array([[3.,0.],[8.,0.],[16.,0.],[25.,0.]])
        cand=np.vstack([grid,c]); D=cdist(c,x); H=cdist(cand,x)
        w=np.array([100.,200.,300.]); nets=np.array(['A','A','B'])
        r=validation(D,H,D,H,c,cand,w,w,D,H,nets,np.array([True,True,False]),len(grid),(H<=5)@w,1)
        self.assertEqual(len(r),14)
        self.assertTrue((r.missed_resident_equivalents>=-1e-8).all())
        self.assertTrue((r[r.method=='population_walk_network'].missed_resident_equivalents<1e-8).all())

    def test_outside_option_against_full_recompute(self):
        rng=np.random.default_rng(21)
        D=rng.integers(1,20,(4,50)).astype(float)
        H=rng.integers(1,20,(12,50)).astype(float)
        nets=np.array(['A','B','A','C']);w=rng.uniform(1,100,50)
        new,gain,base,q=shares(D,nets,w,'A',H,max_distance=8)
        self.assertLess(q.sum(),w.sum())
        for i,h in enumerate(H):
            X=np.vstack([D,h]);t=(X==X.min(axis=0)) & (X<=8)
            probs=t/np.maximum(t.sum(axis=0),1);q2=probs@w
            self.assertAlmostEqual(new[i],q2[-1])
            self.assertAlmostEqual(gain[i],q2[np.r_[nets=='A',True]].sum()-base)

    def test_parallel_edges_use_shortest(self):
        G=nx.MultiDiGraph()
        G.add_node(1,x=0,y=0);G.add_node(2,x=100,y=0)
        G.add_edge(1,2,length=500);G.add_edge(1,2,length=100)
        d,_,_=graph_distances(G,np.array([[0,0]]),np.array([[100,0]]))
        self.assertEqual(d[0,0],100)

    def test_population_conservation_and_levels(self):
        import geopandas as gpd
        from shapely.geometry import box
        from model import prepare_buildings
        g=gpd.GeoDataFrame({'building':['apartments']*3,'building:levels':['10',None,'bad']},
            geometry=[box(1,1,11,11),box(20,1,40,11),box(50,1,60,11)],crs=32637)
        out=prepare_buildings(g,box(0,0,100,100),400)
        np.testing.assert_allclose(out.residents,[100,200,100])
        self.assertEqual(out.levels_observed.sum(),1)

    def test_zone_separation(self):
        import pandas as pd
        from robustness import separated_zones
        t=pd.DataFrame({'x':[0,10,600,1200],'y':[0]*4,'gain_walk':[100,99,80,70],'eligible':[True]*4})
        out=separated_zones(t)
        self.assertEqual(list(out.index),[0,2,3])

if __name__=='__main__': unittest.main()
